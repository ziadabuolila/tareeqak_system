1:"$Sreact.fragment"
2:I[8158,["3061","static/chunks/3061-ccf8c6e42e250be0.js","7177","static/chunks/app/layout-ab852ab4a7912f11.js"],"Toaster"]
3:I[6246,["3061","static/chunks/3061-ccf8c6e42e250be0.js","7177","static/chunks/app/layout-ab852ab4a7912f11.js"],"default"]
4:I[6292,["3061","static/chunks/3061-ccf8c6e42e250be0.js","7177","static/chunks/app/layout-ab852ab4a7912f11.js"],"LiveRefreshProvider"]
5:I[2769,["3061","static/chunks/3061-ccf8c6e42e250be0.js","7177","static/chunks/app/layout-ab852ab4a7912f11.js"],"default"]
6:I[5592,["3061","static/chunks/3061-ccf8c6e42e250be0.js","7177","static/chunks/app/layout-ab852ab4a7912f11.js"],"default"]
7:I[2006,["3061","static/chunks/3061-ccf8c6e42e250be0.js","7177","static/chunks/app/layout-ab852ab4a7912f11.js"],"default"]
8:I[5204,[],""]
9:I[2642,[],""]
a:I[8197,["8197","static/chunks/8197-f05fdd869613ec30.js","4345","static/chunks/app/not-found-c0e50fffddb23719.js"],""]
b:I[7089,[],"ClientPageRoot"]
c:I[8546,["3061","static/chunks/3061-ccf8c6e42e250be0.js","8197","static/chunks/8197-f05fdd869613ec30.js","4854","static/chunks/app/password/page-1f8d211a3f465779.js"],"default"]
f:I[433,[],"OutletBoundary"]
11:I[9884,[],"AsyncMetadataOutlet"]
13:I[433,[],"ViewportBoundary"]
15:I[433,[],"MetadataBoundary"]
16:"$Sreact.suspense"
18:I[3536,[],""]
:HL["/_next/static/css/49514179bd2bb064.css","style"]
:HL["/_next/static/css/2bc8599ae325d46f.css","style"]
:HL["/_next/static/css/2dd609279395368e.css","style"]
0:{"P":null,"b":"BGzta_Yf1EgP3XqgdHYu1","p":"","c":["","password"],"i":false,"f":[[["",{"children":["password",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/49514179bd2bb064.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/2bc8599ae325d46f.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","2",{"rel":"stylesheet","href":"/_next/static/css/2dd609279395368e.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"ar","dir":"rtl","children":["$","body",null,{"children":[["$","$L2",null,{"dir":"rtl","position":"top-center","richColors":true,"closeButton":true,"duration":6500}],["$","$L3",null,{}],["$","$L4",null,{}],["$","$L5",null,{}],["$","$L6",null,{}],["$","$L7",null,{"children":["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","main",null,{"style":{"minHeight":"100vh","display":"grid","placeItems":"center","padding":"2rem","fontFamily":"Cairo, sans-serif","direction":"rtl"},"children":["$","div",null,{"style":{"maxWidth":520,"width":"100%","textAlign":"center","padding":"2rem","borderRadius":20,"background":"#f6f7f8","boxShadow":"0 10px 30px rgba(0,0,0,0.08)"},"children":[["$","h1",null,{"style":{"margin":0,"fontSize":"3rem","color":"#0f172a"},"children":"404"}],["$","h2",null,{"style":{"margin":"0.75rem 0","color":"#0f172a"},"children":"الصفحة غير موجودة"}],["$","p",null,{"style":{"margin":"0 0 1.5rem","color":"#475569","lineHeight":1.7},"children":"الرابط الذي حاولت الوصول إليه غير موجود أو تم نقله."}],["$","$La",null,{"href":"/","style":{"display":"inline-block","textDecoration":"none","background":"#0f766e","color":"#fff","padding":"0.85rem 1.4rem","borderRadius":12,"fontWeight":700},"children":"العودة للرئيسية"}]]}]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]}]]}],{"children":["password",["$","$1","c",{"children":[null,["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$Lb",null,{"Component":"$c","searchParams":{},"params":{},"promises":["$@d","$@e"]}],null,["$","$Lf",null,{"children":["$L10",["$","$L11",null,{"promise":"$@12"}]]}]]}],{},null,false]},null,false]},null,false],["$","$1","h",{"children":[null,[["$","$L13",null,{"children":"$L14"}],null],["$","$L15",null,{"children":["$","div",null,{"hidden":true,"children":["$","$16",null,{"fallback":null,"children":"$L17"}]}]}]]}],false]],"m":"$undefined","G":["$18",[]],"s":false,"S":true}
d:{}
e:"$0:f:0:1:2:children:2:children:1:props:children:0:props:params"
14:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
10:null
12:{"metadata":[["$","title","0",{"children":"طريقك | لوحة التحكم"}],["$","meta","1",{"name":"description","content":"لوحة تحكم منصة طريقك للبلاغات المجتمعية"}]],"error":null,"digest":"$undefined"}
17:"$12:metadata"
